package animals;

public abstract class Flying extends Bird {

}
