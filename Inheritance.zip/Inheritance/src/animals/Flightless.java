package animals;

public abstract class Flightless extends Bird {

}
